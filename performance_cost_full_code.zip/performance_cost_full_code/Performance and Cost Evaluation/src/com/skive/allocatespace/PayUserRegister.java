/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.skive.allocatespace;
import com.skive.database.DB;
import com.skive.time.SimpleDateFormatExample;
/**
 *
 * @author SKIVE ACADEMY 5
 */
public class PayUserRegister {
   public static boolean allocateCloudSpace(String username,int space,int validity){
       int spaceDetails=1024*space;
       String curDate=SimpleDateFormatExample.defaultTime();
       boolean payStatus=DB.payUserRegister(username, curDate, spaceDetails, validity);
       if(payStatus==true){
           return true;
       }
       return false;
   } 
}
