/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.skive.allocatespace;
import java.text.SimpleDateFormat;
import java.util.*;
import com.skive.time.SimpleDateFormatExample;
import com.skive.database.DB;

/**
 *
 * @author SKIVE ACADEMY 5
 */
public class FreeUser {
    final static int CLOUD_SPCACE=1024*1;
    final static int FREE_USER_VALIDITY=1;
    public static boolean allocateFreeUserSpace(String username){
        String curdate=SimpleDateFormatExample.defaultTime();
        boolean status=DB.freeUserRegister(username, curdate, CLOUD_SPCACE,FREE_USER_VALIDITY);
        System.out.println("current Time :"+curdate);
        if(status==true){
            return true;
        }
        return false;  
    }
}
