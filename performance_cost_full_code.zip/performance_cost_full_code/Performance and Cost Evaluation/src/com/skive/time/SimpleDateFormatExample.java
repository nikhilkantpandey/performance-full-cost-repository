/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.skive.time;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 *
 * @author SKIVE ACADEMY 5
 */
public class SimpleDateFormatExample {
    	    public static String defaultTime() {
        Date curDate = new Date(); 
        SimpleDateFormat format = new SimpleDateFormat();
        String DateToStr = format.format(curDate);
        System.out.println("Default pattern: " + DateToStr);
        try {
            Date strToDate = format.parse(DateToStr);
            System.out.println(strToDate);
        } catch (ParseException e) {
            e.printStackTrace();
        }
                    return DateToStr;
    }
            public static String simpleDateFormat1(){
                Date curDate = new Date(); 
                SimpleDateFormat format = new SimpleDateFormat();
                format = new SimpleDateFormat("MM/dd/yyyy hh:mm:ss");
               String DateToStr = format.format(curDate);
                    return DateToStr;  
            }
            public static String simpleDateFormat2(){
                                Date curDate = new Date(); 
                SimpleDateFormat format = new SimpleDateFormat();
                format = new SimpleDateFormat("dd MMMM yyyy zzzz", Locale.ENGLISH);
                String DateToStr = format.format(curDate);
                System.out.println(DateToStr);                
                return DateToStr; 
            }
            public static String simpleDateFormat3(){
                Date curDate = new Date(); 
                SimpleDateFormat format = new SimpleDateFormat();
                format = new SimpleDateFormat("dd-M-yyyy hh:mm:ss");
                String DateToStr = format.format(curDate);
                System.out.println(DateToStr);
                return DateToStr;
            }
            public static String simpleDateFormat4(){
                Date curDate = new Date(); 
                SimpleDateFormat format = new SimpleDateFormat();
                format = new SimpleDateFormat("MMMM dd HH:mm:ss zzzz yyyy",
                Locale.ITALIAN);
                String DateToStr = format.format(curDate);
                System.out.println(DateToStr);
                return DateToStr;
            }
            public static String simpleDateFormat5(){
                Date curDate = new Date(); 
                SimpleDateFormat format = new SimpleDateFormat();   
                format = new SimpleDateFormat("HH:mm a");
                String DateToStr = format.format(curDate);
                System.out.println(DateToStr);
                return DateToStr;
            }
            public static void main(String args[]){
               String s= SimpleDateFormatExample.simpleDateFormat5();
               System.out.println(s);
            }
}
