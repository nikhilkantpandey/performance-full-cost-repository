/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.skive.userpackages;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.Socket;

/**
 *
 * @author SKIVE ACADEMY 5
 */
public class DownloadPerformance {
    public static void download(String File) throws IOException{
        Socket socket = new Socket("localhost",15255);
        InputStream input = socket.getInputStream();
        OutputStreamWriter outputStream = new OutputStreamWriter(socket.getOutputStream());
        BufferedWriter outReader = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        outputStream.write(File+ "\n");
        outputStream.flush();
         /* Get reponse from server */
         BufferedReader inReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
         String serverStatus = inReader.readLine(); // Read the first line
         try{
         if ( serverStatus.equals("READY") ){
                outReader.write("READY\n");
                outReader.flush();
             FileOutputStream wr = new FileOutputStream(new File("C://Doserver/" + File));
             byte[] buffer = new byte[socket.getReceiveBufferSize()];
              int bytesReceived = 0;
                    while((bytesReceived = input.read(buffer))>0)
                    {
                        /* Write to the file */
                       wr.write(buffer,0,bytesReceived);
                       System.out.println("server recevied the file");
                    }
              System.out.println("file received Successfully. ");     
        }
         }catch(Exception e){
             System.out.println(e);
         }
    }
}
