/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.skive.cloud;
import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;
import javax.swing.JOptionPane;
/**
 *
 * @author SKIVE ACADEMY 5
 */
public class DownloadServer {
     public static void main (String [] args ) throws IOException, InterruptedException {
         System.out.println("Listening port ....15255 ...");
            ServerSocket serverSocket = new ServerSocket(15255);
            Socket socket = serverSocket.accept();
            System.out.println("Accepted connection : " + socket);
            OutputStream output = socket.getOutputStream();
            BufferedReader inReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            BufferedWriter outReader = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
             /* Read the filename */
            String filename = inReader.readLine();
            System.out.println("filename :"+filename);
            if ( !filename.equals("") ){
                /* Reply back to client with READY status */
                outReader.write("READY\n");
                outReader.flush();
            }
                try{
                FileInputStream file = new FileInputStream("C://server/"+filename);
                byte[] buffer = new byte[socket.getSendBufferSize()];
                int bytesRead = 0;
                while((bytesRead = file.read(buffer))>0) {
                    output.write(buffer,0,bytesRead);
                    output.flush();
                    System.out.println("file trasfer complete server to client");
                }
                  
                }catch(Exception e){
                       System.out.println("File not found in server"); 
                        
                }  
        }  
}
