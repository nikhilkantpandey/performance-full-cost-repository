/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.skive.cloud;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author SKIVE ACADEMY 5
 */
public class Server {
    public static void main (String [] args ) throws IOException, ClassNotFoundException {
    
         System.out.println("Server running...");
 
        /* Listen on port 15123 */
        ServerSocket serverSocket = new ServerSocket(151);
        Socket socket = serverSocket.accept();
        System.out.println("Accepted connection : " + socket);
        InputStream input = socket.getInputStream();
        BufferedReader inReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
        BufferedWriter outReader = new BufferedWriter(new OutputStreamWriter(socket.getOutputStream()));
        
        /* Read the filename */
        String filename = inReader.readLine();
        System.out.println("filename :"+filename);
        if ( !filename.equals("") ){
             /* Reply back to client with READY status */
            outReader.write("READY\n");
            outReader.flush();
            
        }
        
        /* Create a new file in the tmp directory using the filename */
        FileOutputStream wr = new FileOutputStream(new File("C://server/" + filename));
 
        byte[] buffer = new byte[socket.getReceiveBufferSize()];
 
        int bytesReceived = 0;
 
        while((bytesReceived = input.read(buffer))>0)
        {
            /* Write to the file */
           wr.write(buffer,0,bytesReceived);
           System.out.println("server recevied the file");
        }
}
}
