package com.skive.database;

import java.sql.*;
import java.util.ArrayList;

import javax.mail.internet.InternetAddress;

public class DB {
	final static String DB_URL = "jdbc:mysql://localhost/cost_evaluvation";
	final static String USER = "root";
	final static String PASS = "admin";
	static Connection con;
	static Connection conn;
	static Statement st,stmt;
	static PreparedStatement pst;
	static ResultSet rst;
	public static boolean RegisterUser(String FName,String LName,String userName,String Pass,String Email,String Phone,String status){
		try{
			String regUser="insert into userdetails(fname, lname, uname, pass, email, phone, type) values('"+FName+"','"+LName+"','"+userName+"','"+Pass+"','"+Email+"','"+Phone+"','"+status+"')";
			pst=DB.con().prepareStatement(regUser);
			int t=pst.executeUpdate();
			if(t>0){
				return true;
			}else{
				return false;
			}
		}catch(Exception e){
			System.out.println("Error in Register To DB : "+e);
			return false;
		}
	}
	
	public static boolean loginCheck(String userName,String pass){
		try {
			String checkUser="select uid, fname, lname, uname, pass, email, phone, type from userdetails where uname='"+userName+"'";
			stmt=DB.con().createStatement();
			rst=stmt.executeQuery(checkUser);
			if(rst.next()){
				String password=rst.getString(5);
				if(pass.equals(password)){
					return true;
				}
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			return false;
		}
		return false;
	}
	
	public static boolean logDetails(String email,String hostname,String ip,String currenturl,String accesstime,String system){
		try{
			pst=DB.con().prepareStatement("insert into logdetails(userid,userhostname,useripaddress,currenturl,accesstime,systemtype)values ((select uid from userdetails where email='"+email+"'),'"+hostname+"','"+ip+"','"+currenturl+"','"+accesstime+"','"+system+"')");
			int t=pst.executeUpdate();
			if(t>0){
				return true;
			}else{
				return false;
			}
		}catch(Exception e){
			System.out.println(e);
			return false;
		}
	}
	public static ArrayList<String> Results(String email){
		try{
			ArrayList <String> cid=new ArrayList <String>();
			ArrayList <String> mail=new ArrayList <String>();
			ArrayList <String> user=new ArrayList <String>();
			ArrayList <String> sub=new ArrayList <String>();
			ArrayList <String> afile=new ArrayList <String>();
			ArrayList <String> dat=new ArrayList <String>();
			String checkUser="select c.composeid,c.mailbody,u.username,c.subject,c.attachedfile,c.date from userdetails u,composemail c where c.toaddress='"+email+"' and u.userid=c.userid";
			stmt=DB.con().createStatement();
			rst=stmt.executeQuery(checkUser);
			while(rst.next()){
				cid.add(rst.getString(1));
				mail.add(rst.getString(2));
				user.add(rst.getString(3));
				sub.add(rst.getString(4));
				afile.add(rst.getString(5));
				dat.add(rst.getString(6));
			}
		}catch(Exception e){
			System.out.println(e);
		}
		return null;
		
	}
	public static Connection con(){
		try{
			Class.forName("com.mysql.jdbc.Driver");
			con=DriverManager.getConnection(DB_URL,USER,PASS);
			return con;
		}catch(Exception e){
			System.out.println(e);
			return null;
		}
	}
	public static boolean composeEntry(String email,String toAddress,String sub,String mailBody,String attachFile,String date,int recipientCount){
		try{
			String composeEntryQuery="insert into composemail(userid,toaddress,subject,mailbody,attachedfile,date,recipientcount)values ((select uid from userdetails where email='"+email+"'),'"+toAddress+"','"+sub+"','"+mailBody+"','"+attachFile+"','"+date+"','"+recipientCount+"')";
			pst=DB.con().prepareStatement(composeEntryQuery);
			int t=pst.executeUpdate();
			if(t>0){
				return true;
			}
		}catch(Exception e){
			System.out.println(e);
			return false;
		}
		return false;
	}
        public static boolean freeUserRegister(String userName,String curDate,int space,int validity){
            
            String query="insert into clouduserdetails(uname, freespace, curdate, uid, utype, validity) values('"+userName+"','"+space+"','"+curDate+"',(SELECT uid  from userdetails order by uid desc limit 1),'FREE USER','"+validity+"')";
            try{
               pst=DB.con().prepareStatement(query);
               int t=pst.executeUpdate();
               if(t>0){
                   return true;
               }
            }catch(Exception e){
                System.out.println("free User Regsitration :"+e);
              return false;  
            }
            return false;  
        }
                public static boolean payUserRegister(String userName,String curDate,int space,int validity){
            
            String query="insert into clouduserdetails(uname, freespace, curdate, uid, utype, validity) values('"+userName+"','"+space+"','"+curDate+"',(SELECT uid  from userdetails order by uid desc limit 1),'PAID USER','"+validity+"')";
            try{
               pst=DB.con().prepareStatement(query);
               int t=pst.executeUpdate();
               if(t>0){
                   return true;
               }
            }catch(Exception e){
                System.out.println("pay User Regsitration :"+e);
              return false;  
            }
            return false;  
        }
        public static boolean enterFileDetails(String filename,String filesize,String starttime , String username,String metaname,String dataname){
            
            String query="insert into filedetails(filename, filesize, starttime, username, metaname, dataname) values('"+filename+"','"+filesize+"','"+starttime+"','"+username+"','"+metaname+"','"+dataname+"')";
            try{
               pst=DB.con().prepareStatement(query);
               int t=pst.executeUpdate();
               if(t>0){
                   return true;
               }
            }catch(Exception e){
                System.out.println("Enter File details  :"+e);
              return false;  
            }
            return false;  
        }
         public static boolean enterUpdateFiledetails(String endTime,String duration){
            
            String query="update filedetails set finishtime='"+endTime+"' , duration='"+duration+"' order by fid desc limit 1";
            try{
               pst=DB.con().prepareStatement(query);
               int t=pst.executeUpdate();
            }catch(Exception e){
                System.out.println("Update filedetails  :"+e);
              return false;  
            }
            return false;  
        }
         public static boolean downloadFileDetails(String uname, String filename,String stime){
            
            String query="insert into downloadfiles(uname, filename, stime ) values('"+uname+"','"+filename+"','"+stime+"')";
            try{
               pst=DB.con().prepareStatement(query);
               int t=pst.executeUpdate();
               if(t>0){
                   return true;
               }
            }catch(Exception e){
                System.out.println("Enter File details  :"+e);
              return false;  
            }
            return false;  
        }
         public static boolean downloadUpdateFiledetails(String etime,String timedifference){
            
            String query="update downloadfiles set etime='"+etime+"' , timedifference='"+timedifference+"' order by did desc limit 1";
            try{
               pst=DB.con().prepareStatement(query);
               int t=pst.executeUpdate();
            }catch(Exception e){
                System.out.println("Update filedetails  :"+e);
              return false;  
            }
            return false;  
        }
         	public static boolean userCheck(String userName){
		try {
			String checkUser="select * from userdetails where uname='"+userName+"'";
			stmt=DB.con().createStatement();
			rst=stmt.executeQuery(checkUser);
			if(rst.next()){
				String usertype=rst.getString(5);
				if(usertype.equals("FREE USER")){
					return false;
				}else if(usertype.equals("PAID USER")){
                                    return true;
                                }
				return false;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println(e);
			return false;
		}
		return false;
	}
}
