/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.mohan.Encryption;
import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;

import javax.crypto.Cipher;
import javax.crypto.CipherInputStream;
import javax.crypto.CipherOutputStream;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import java.io.*;
import java.net.Socket;
import javax.swing.JOptionPane;

/**
 *
 * @author SKIVE ACADEMY 5
 */
public class fileEncryption {
    static String s="";
    static String server="localhost";
    static String remoteServer="localhost";

	public fileEncryption(String filepath,String Key,String filename) {
		try {

			String key = "mohanrajcmr"; // needs to be at least 8 characters for DES
                        String Filename=filepath;
                        String name=filename;
                        System.out.println("name = "+name);
                         File f=new File("");
                         System.out.println("filename :"+filename);
                         System.out.println("file path :"+filepath);

                        String path=f.getAbsolutePath();
                        System.out.println(path);
			FileInputStream fis = new FileInputStream(Filename);
                        FileOutputStream fos = new FileOutputStream("D:\\EncryptedFile\\"+name);
                        String filepa="D:\\EncryptedFile\\"+name;

			//FileOutputStream fos = new FileOutputStream(path+"\\"+name);
			encrypt(key, fis, fos);
                        server(name,filepa);
 


//                        File f=new File("");
//                        File m=new File(Filename);
//                        String g=m.getName();
//                        String path=f.getAbsolutePath();
//                        System.out.println(path);
//			FileInputStream fis2 = new FileInputStream(Filename);
//			FileOutputStream fos2 = new FileOutputStream(path+"\\"+g);
//			decrypt(key, fis2, fos2);


		} catch (Throwable e) {
			e.printStackTrace();
		}
	}

	public static void encrypt(String key, InputStream is, OutputStream os) throws Throwable {
		encryptOrDecrypt(key, Cipher.ENCRYPT_MODE, is, os);
	}
        
        public static void server(String filename,String path){
            
             try { 
                    Socket socket = new Socket(server,15123);
                    OutputStream output = socket.getOutputStream();
                    OutputStreamWriter outputStream = new OutputStreamWriter(socket.getOutputStream());
                    outputStream.write(filename+ "\n");
                    outputStream.flush();
                    /* Get reponse from server */
                    BufferedReader inReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String serverStatus = inReader.readLine(); // Read the first line
                    /* If server is ready, send the file */
                    if ( serverStatus.equals("READY") ){
                        FileInputStream file = new FileInputStream(path);
                        byte[] buffer = new byte[socket.getSendBufferSize()];
                        int bytesRead = 0;
                        while((bytesRead = file.read(buffer))>0) {
                            output.write(buffer,0,bytesRead);
                            output.flush();
                            System.out.println("file trasfer complete client to server");
                            Thread.sleep(500);
                        }
                        
                    }
                                    
                                }catch(Exception e){
                                    e.printStackTrace();
                                    
                                }
          
            
            
        }
        
        public static void remoteServer(String filename,String path) {
                         try { 
                    Socket socket = new Socket(server,15155);
                    OutputStream output = socket.getOutputStream();
                    OutputStreamWriter outputStream = new OutputStreamWriter(socket.getOutputStream());
                    outputStream.write(filename+ "\n");
                    outputStream.flush();
                    /* Get reponse from server */
                    BufferedReader inReader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
                    String serverStatus = inReader.readLine(); // Read the first line
                    /* If server is ready, send the file */
                    if ( serverStatus.equals("READY") ){
                        FileInputStream file = new FileInputStream(path);
                        byte[] buffer = new byte[socket.getSendBufferSize()];
                        int bytesRead = 0;
                        while((bytesRead = file.read(buffer))>0) {
                            output.write(buffer,0,bytesRead);
                            output.flush();
                            System.out.println("file trasfer complete client to remote server");
                        }
                        
                    }
                                    
                                }catch(Exception e){
                                    e.printStackTrace();
                                    
                                }
            
        }

//	public static void decrypt(String key, InputStream is, OutputStream os) throws Throwable {
//		encryptOrDecrypt(key, Cipher.DECRYPT_MODE, is, os);
//	}

	public static void encryptOrDecrypt(String key, int mode, InputStream is, OutputStream os) throws Throwable {

		DESKeySpec dks = new DESKeySpec(key.getBytes());
		SecretKeyFactory skf = SecretKeyFactory.getInstance("DES");
		SecretKey desKey = skf.generateSecret(dks);
		Cipher cipher = Cipher.getInstance("DES"); // DES/ECB/PKCS5Padding for SunJCE

		if (mode == Cipher.ENCRYPT_MODE) {
			cipher.init(Cipher.ENCRYPT_MODE, desKey);
			CipherInputStream cis = new CipherInputStream(is, cipher);
			doCopy(cis, os);
                        
		}
                
//                       else if (mode == Cipher.DECRYPT_MODE) {
//			cipher.init(Cipher.DECRYPT_MODE, desKey);
//			CipherOutputStream cos = new CipherOutputStream(os, cipher);
//			doCopy(is, cos);
//		}
	}

	public static void doCopy(InputStream is, OutputStream os) throws IOException {
		byte[] bytes = new byte[64];
		int numBytes;
		while ((numBytes = is.read(bytes)) != -1) {

			os.write(bytes, 0, numBytes);
		}
		os.flush();
		os.close();
		is.close();
	}

}
