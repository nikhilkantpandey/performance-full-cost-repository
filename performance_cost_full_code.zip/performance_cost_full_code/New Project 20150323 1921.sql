-- MySQL Administrator dump 1.4
--
-- ------------------------------------------------------
-- Server version	5.0.67-community-nt


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


--
-- Create schema cost_evaluvation
--

CREATE DATABASE IF NOT EXISTS cost_evaluvation;
USE cost_evaluvation;

--
-- Definition of table `clouduserdetails`
--

DROP TABLE IF EXISTS `clouduserdetails`;
CREATE TABLE `clouduserdetails` (
  `cid` int(10) unsigned NOT NULL auto_increment,
  `uname` varchar(45) NOT NULL,
  `freespace` varchar(45) NOT NULL,
  `curdate` varchar(45) NOT NULL,
  `uid` varchar(45) NOT NULL,
  `utype` varchar(45) NOT NULL,
  `validity` varchar(45) default NULL,
  PRIMARY KEY  (`cid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `clouduserdetails`
--

/*!40000 ALTER TABLE `clouduserdetails` DISABLE KEYS */;
INSERT INTO `clouduserdetails` (`cid`,`uname`,`freespace`,`curdate`,`uid`,`utype`,`validity`) VALUES 
 (1,'mohan','1024','2/28/15 10:56 AM','1','FREE USER',NULL),
 (2,'kala','3072','2/28/15 11:33 AM','2','PAID USER','3'),
 (3,'raj','1024','2/28/15 11:51 AM','3','FREE USER','1'),
 (4,'raj1','10240','2/28/15 11:51 AM','4','PAID USER','100'),
 (5,'kala','1024','3/12/15 11:32 AM','5','FREE USER','1'),
 (6,'kala','102400','3/12/15 11:34 AM','6','PAID USER','10'),
 (7,'','1024','3/23/15 5:34 PM','7','FREE USER','1');
/*!40000 ALTER TABLE `clouduserdetails` ENABLE KEYS */;


--
-- Definition of table `downloadfiles`
--

DROP TABLE IF EXISTS `downloadfiles`;
CREATE TABLE `downloadfiles` (
  `did` int(10) unsigned NOT NULL auto_increment,
  `uname` varchar(45) NOT NULL,
  `filename` varchar(45) NOT NULL,
  `stime` varchar(45) NOT NULL,
  `etime` varchar(45) default NULL,
  `timedifference` varchar(45) default NULL,
  PRIMARY KEY  (`did`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `downloadfiles`
--

/*!40000 ALTER TABLE `downloadfiles` DISABLE KEYS */;
INSERT INTO `downloadfiles` (`did`,`uname`,`filename`,`stime`,`etime`,`timedifference`) VALUES 
 (1,'mohan','cloud server.jpg','03/23/2015 06:20:11',NULL,NULL),
 (2,'mohan','Doc1.docx','03/23/2015 06:23:03','03/23/2015 06:23:03','mohan'),
 (3,'mohan','ANDROID.pdf','03/23/2015 06:24:44','03/23/2015 06:24:44','mohan'),
 (4,'mohan','ANDROID.pdf','03/23/2015 06:54:25','03/23/2015 06:54:25','mohan');
/*!40000 ALTER TABLE `downloadfiles` ENABLE KEYS */;


--
-- Definition of table `filedetails`
--

DROP TABLE IF EXISTS `filedetails`;
CREATE TABLE `filedetails` (
  `fid` int(10) unsigned NOT NULL auto_increment,
  `filename` varchar(45) NOT NULL,
  `filesize` varchar(45) NOT NULL,
  `starttime` varchar(45) NOT NULL,
  `finishtime` varchar(45) default NULL,
  `duration` varchar(45) default NULL,
  `username` varchar(45) NOT NULL,
  `metaname` varchar(45) NOT NULL,
  `dataname` varchar(45) NOT NULL,
  PRIMARY KEY  (`fid`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `filedetails`
--

/*!40000 ALTER TABLE `filedetails` DISABLE KEYS */;
INSERT INTO `filedetails` (`fid`,`filename`,`filesize`,`starttime`,`finishtime`,`duration`,`username`,`metaname`,`dataname`) VALUES 
 (1,'Doc1.docx','223885','03/23/2015',NULL,NULL,'maha','cloud comuting','cloud files'),
 (2,'ANDROID.pdf','500907','03/23/2015',NULL,NULL,'kala','saas','iaas'),
 (3,'cloud server.jpg','39221','03/23/2015','03/23/2015','60','myna','cloud','cloud computing'),
 (4,'4.jpg','4741','03/23/2015','03/23/2015','null','myna','data','cloud computing'),
 (5,'Android Project Title.docx','12541','03/23/2015','03/23/2015','60','kala','mohan','mohan'),
 (6,'Cloud Assisted.docx','319320','03/23/2015 03:40:16','03/23/2015 03:40:36','50','kkkk','mala','cloud computing');
/*!40000 ALTER TABLE `filedetails` ENABLE KEYS */;


--
-- Definition of table `userdetails`
--

DROP TABLE IF EXISTS `userdetails`;
CREATE TABLE `userdetails` (
  `uid` int(10) unsigned NOT NULL auto_increment,
  `fname` varchar(45) NOT NULL,
  `lname` varchar(45) NOT NULL,
  `uname` varchar(45) NOT NULL,
  `pass` varchar(45) NOT NULL,
  `email` varchar(45) NOT NULL,
  `phone` varchar(45) NOT NULL,
  `type` varchar(45) NOT NULL,
  PRIMARY KEY  (`uid`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `userdetails`
--

/*!40000 ALTER TABLE `userdetails` DISABLE KEYS */;
INSERT INTO `userdetails` (`uid`,`fname`,`lname`,`uname`,`pass`,`email`,`phone`,`type`) VALUES 
 (1,'Mohan','Raj','mohan','mohan','mohan@fabsys.in','9666666','FREE USER'),
 (2,'kala','kala','kala','kala','mohan@fabsys.in','99999999','PAID USER'),
 (3,'raj','raj','raj','raj','raj','raj','FREE USER'),
 (4,'raj1','raj1','raj1','raj1','raj1','raj1','PAID USER'),
 (5,'kala','kala','kala','kala','mohan@fabsys.in','9999999999','FREE USER'),
 (6,'kala','kala','kala','kala','mohan@fabsys.in','999999999','PAID USER'),
 (7,'','','','','','','FREE USER');
/*!40000 ALTER TABLE `userdetails` ENABLE KEYS */;




/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
